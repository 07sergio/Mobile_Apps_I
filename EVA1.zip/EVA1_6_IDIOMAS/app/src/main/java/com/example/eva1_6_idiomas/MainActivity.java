package com.example.eva1_6_idiomas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener{

    TextView txvNombre, txvApellido, txvEdad, txvIdioma;
    EditText edtNombre, edtApellido, edtEdad;
    RadioGroup rdGrpIdioma;
    RadioButton rbEs, rbEn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txvNombre = findViewById(R.id.txvNombre);
        txvApellido = findViewById(R.id.txvApellido);
        txvEdad = findViewById(R.id.txvEdad);
        txvIdioma = findViewById(R.id.txvIdioma);
        edtNombre = findViewById(R.id.edtNombre);
        edtApellido = findViewById(R.id.edtApellido);
        edtEdad = findViewById(R.id.edtEdad);
        rdGrpIdioma = findViewById(R.id.rGrpIdioma);
        rbEn = findViewById(R.id.rbEn);
        rbEs = findViewById(R.id.rbEs);

        rdGrpIdioma.setOnCheckedChangeListener(this);

    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if(checkedId == R.id.rbEs){
            txvIdioma.setText(R.string.idioma_es);
            rbEs.setText(R.string.espanol_es);
            rbEn.setText(R.string.ingles_es);
            txvNombre.setText(R.string.txt_nombre_es);
            edtNombre.setHint(R.string.hint_nombre_es);
            txvApellido.setText(R.string.txt_apellido_es);
            edtApellido.setHint(R.string.hint_apellido_es);
            txvEdad.setText(R.string.txt_edad_es);
            edtEdad.setHint(R.string.hint_edad_es);

        }else{
            txvIdioma.setText(R.string.idioma_en);
            rbEs.setText(R.string.espanol_en);
            rbEn.setText(R.string.ingles_en);
            txvNombre.setText(R.string.txt_nombre_en);
            edtNombre.setHint(R.string.hint_nombre_en);
            txvApellido.setText(R.string.txt_apellido_en);
            edtApellido.setHint(R.string.hint_apellido_en);
            txvEdad.setText(R.string.txt_edad_en);
            edtEdad.setHint(R.string.hint_edad_en);
        }

    }
}
