package com.example.eva_2_layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edtTxtNombre, edtTxtApellido, edtTxtEdad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtTxtNombre = findViewById(R.id.edtTxtNombre);
        edtTxtApellido = findViewById(R.id.edtTxtApellido);
        edtTxtEdad  = findViewById(R.id.edtTxtEdad);
    }
}
