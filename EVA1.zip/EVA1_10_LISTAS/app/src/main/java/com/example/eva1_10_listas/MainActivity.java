package com.example.eva1_10_listas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener {

    ListView lstAlbum;
    String[] canciones = {
            "Cancion 1","Cancion 2","Cancion 3","Cancion 4",
            "Cancion 5","Cancion 6","Cancion 7","Cancion 8",
            "Cancion 9","Cancion 10","Cancion 11","Cancion 12"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lstAlbum = findViewById(R.id.lstAlbum);
        lstAlbum.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, canciones));
        lstAlbum.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(), canciones[position], Toast.LENGTH_SHORT).show();
    }
}
