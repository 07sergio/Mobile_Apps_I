package com.example.eva1_11_clima;

public class Weather {

    private String city, desc;
    private int temp, image;

    public Weather(String city, int temp, String desc, int image) {
        this.city = city;
        this.desc = desc;
        this.temp = temp;
        this.image = image;
    }

    public String getCity() {
        return city;
    }

    public String getDesc() {
        return desc;
    }

    public int getTemp() {
        return temp;
    }

    public int getImage() {
        return image;
    }




}
