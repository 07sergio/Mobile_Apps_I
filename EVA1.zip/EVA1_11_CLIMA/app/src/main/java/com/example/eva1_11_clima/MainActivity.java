package com.example.eva1_11_clima;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView lstVwClima;
    Weather[] cities = {
            new Weather("Chihuahua",20, "Nublado", R.drawable.light_rain),
            new Weather("Delicias", -5, "Tornado",R.drawable.sunny),
            new Weather("Ciudad Juarez", -3, "Nevadas",R.drawable.sunny),
            new Weather("Jimenez", 23, "Soleado",R.drawable.sunny),
            new Weather("Camargo", 30, "Soleado",R.drawable.sunny),
            new Weather("Parral", 8, "Vientos fuertes",R.drawable.sunny),
            new Weather("Aldama", -2, "Niebla",R.drawable.sunny),
            new Weather("Batopilas", 10, "Lluvia",R.drawable.sunny),
            new Weather("Creel", 11, "Soleado",R.drawable.sunny),
            new Weather("Casas Grandes", 23, "Lluvias",R.drawable.sunny),
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lstVwClima = findViewById(R.id.lstVwClima);
        lstVwClima.setAdapter(new WeatherAdapter(this, R.layout.mi_layout, cities));
    }
}
