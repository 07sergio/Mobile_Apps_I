package com.example.eva2_2_intents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Intent inTel;
    EditText edNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edNumber = findViewById(R.id.edTxNum);
    }

    public void onClick(View v){
        //FORMANDO UNA URI
        String tel = "tel:"+edNumber.getText().toString();
        if(v.getId() == R.id.btnDial) {
            inTel = new Intent(Intent.ACTION_DIAL, Uri.parse(tel));//2 PARAMETROS: ACCION A EJECUTAR Y DATOS QUE REQUIERE DICHA ACCIÓN (SI ES IMPLICITO VIENE DEFINIDA EN ANDROID)

        }else{
            inTel = new Intent(Intent.ACTION_CALL, Uri.parse(tel));
        }
        startActivity(inTel);

    }
}
