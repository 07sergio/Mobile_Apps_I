package com.example.eva2_6_web;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Intent inWeb;
    Button btnVer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnVer = findViewById(R.id.btnWeb);
    }

    public void onClick(View v){
        String url = "http://www.google.com.mx";
        inWeb = new Intent(Intent.ACTION_VIEW,(Uri.parse(url)));
        startActivity(inWeb);
    }
}
