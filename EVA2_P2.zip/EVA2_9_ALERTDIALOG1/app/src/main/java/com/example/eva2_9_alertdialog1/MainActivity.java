package com.example.eva2_9_alertdialog1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView txtMsg;
    Button btnCustomDialog;
    Button btnAlertDialog;
    Button btnDialogFragment;
    Context activityContext;
    String msg = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activityContext = this;

        txtMsg = (TextView) findViewById(R.id.txtMsg);
        btnAlertDialog = (Button) findViewById(R.id.btnAlertDialog1);
        btnCustomDialog = (Button) findViewById(R.id.btnCustomDialog);
        btnDialogFragment = (Button) findViewById(R.id.btnAlertDialog2);

        btnAlertDialog.setOnClickListener(this);
        btnCustomDialog.setOnClickListener(this);
        btnDialogFragment.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == btnAlertDialog.getId()) {
            showMyAlertDialog(this);
        }
        if (v.getId() == btnCustomDialog.getId()) {
            showCustomDialogBox();
        }
        if (v.getId() == btnDialogFragment.getId()) {
            showMyAlertDialogFragment(this);
        }

    }

    private void showMyAlertDialog(MainActivity mainActivity) {
        new AlertDialog.Builder(mainActivity)
                .setTitle("Terminator")
                .setMessage("Are you sure that you want to quit?")

                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                msg = "YES" + Integer.toString(which);
                                txtMsg.setText(msg);
                            }
                        })
                .setNeutralButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                msg = "CANCEL" + Integer.toString(which);
                                txtMsg.setText(msg);
                            }
                        })
                .setNegativeButton("NO",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                msg = "NO" + Integer.toString(which);
                                txtMsg.setText(msg);
                            }
                        })
                .create()
                .show();
    }



    private void showCustomDialogBox() {
        final Dialog customDialog = new Dialog(activityContext);
        customDialog.setTitle("Custom Dialog Title");

        customDialog.setContentView(R.layout.custom_dialog_layout);

        ((TextView) customDialog.findViewById(R.id.sdTextView1))
                .setText("\nMessage line1\nMessage line2\nDismiss: Back btn, Close, or touch outside");

        final EditText sd_txtInputData = (EditText) customDialog.findViewById(R.id.edTxt1);
        customDialog.findViewById(R.id.btnClose)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        txtMsg.setText(sd_txtInputData.getText().toString());
                        customDialog.dismiss();
                    }
                });
        customDialog.show();
    }

    private void showMyAlertDialogFragment(MainActivity mainActivity) {
        DialogFragment dialogFragment = MyAlertDialogFragment
                .newInstance(R.string.title);
        //dialogFragment.show(getFragmentManager(), "TAG_MYDIALOGFRAGMENT1");
    }

    public void doPositiveClick(Date time) {
        txtMsg.setText("POSITIVE - DialogFragment picked @ " + time);
    }

    public void doNegativeClick(Date time) {
        txtMsg.setText("NEGATIVE - DialogFragment picked @ " + time);
    }

    public void doNeutralClick(Date time){
        txtMsg.setText("NEUTRAL - DialogFragment picked @ " + time);
    }
}
