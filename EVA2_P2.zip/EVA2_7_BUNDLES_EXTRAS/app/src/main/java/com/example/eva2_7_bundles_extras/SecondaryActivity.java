package com.example.eva2_7_bundles_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondaryActivity extends AppCompatActivity {

    TextView txVwDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);
        txVwDatos = findViewById(R.id.txVwDatos);

        Intent inDatos = getIntent();
        String texto = inDatos.getStringExtra("algo");
        Bundle stringBundle = inDatos.getExtras();

        txVwDatos.setText(texto);
        txVwDatos.append("\n");
        txVwDatos.append(stringBundle.getString("usingBundle"));
    }
}
