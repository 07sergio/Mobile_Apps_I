package com.example.eva2_8_activity_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    Button btnAction, btnContact;
    Intent inSelect, inCont;
    final int RESTAURANT = 1;
    final int CONTACT = 2;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            case RESTAURANT:
                //identificar que codigo de respuesta devuelve la actividad
                if (resultCode == Activity.RESULT_OK){
                    Toast.makeText(this,data.getStringExtra("extra"),Toast.LENGTH_LONG).show();//QUE ACCION EJECUTAR CON LOS DATOS DEVUELTOS
                }else{
                    Toast.makeText(this, "CANCELADO", Toast.LENGTH_LONG).show();
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAction = findViewById(R.id.btnAction);
        btnContact = findViewById(R.id.btnContacts);
        inSelect = new Intent(this, MyDataActivity.class); //(CONTEXTO, ACTIVIDAD A LANZAR)
        inCont = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        btnAction.setOnClickListener(new View.OnClickListener(){
            public void onClick(View w){
                startActivityForResult(inSelect,RESTAURANT);//LANZAR SEGUNDA ACTIVIDAD
            }
        });
        btnContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(inCont, CONTACT);
            }
        });
    }
}
