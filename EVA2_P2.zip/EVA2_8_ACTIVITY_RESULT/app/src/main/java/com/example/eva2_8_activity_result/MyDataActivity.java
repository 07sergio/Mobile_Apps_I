package com.example.eva2_8_activity_result;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MyDataActivity extends AppCompatActivity implements ListView.OnItemClickListener, View.OnClickListener {
    Button btnCancel;
    ListView lsVwList;

    String[] Rest = {
            "Restaurante 1",
            "Restaurante 2",
            "Restaurante 3",
            "Restaurante 4",
            "Restaurante 5",
            "Restaurante 6",
            "Restaurante 7",
            "Restaurante 8",
            "Restaurante 9",
            "Restaurante 10",
            "Restaurante 11",
            "Restaurante 12",
            "Restaurante 13",
            "Restaurante 14",
            "Restaurante 15",
            "Restaurante 16"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_data);
        lsVwList = findViewById(R.id.lsVwRest);
        lsVwList.setOnItemClickListener(this);
        lsVwList.setAdapter(new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1,Rest)); //(contexto, layout que ya existe, el arreglo)
        btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent inDatos = new Intent();
        inDatos.putExtra("extra", Rest[position]);
        setResult(Activity.RESULT_OK,inDatos);//NOTIFICAR AL MAIN QUE SE GENERO UN RESULTADO. DISPARA ONACTIVITYRESULT
        finish();
    }

    @Override
    public void onClick(View v) {
        setResult(Activity.RESULT_CANCELED);
        finish();
    }
}
